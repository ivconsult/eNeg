﻿using citPOINT.eNeg.Apps.Common.Interfaces;

namespace TestApp.Helper
{
    /// <summary>
    /// Test App Configuration.
    /// </summary>
    public class TestAppConfiguration
    {
        /// <summary>
        /// Gets or sets the main platform info.
        /// </summary>
        /// <value>The main platform info.</value>
        public static IMainPlatformInfo MainPlatformInfo
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the name of the app.
        /// </summary>
        /// <value>The name of the app.</value>
        public static string AppName
        {
            get
            {
                return "Test App";
            }
        }
    }
}
