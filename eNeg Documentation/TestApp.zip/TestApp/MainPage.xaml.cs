﻿using System.ComponentModel.Composition;
using System.Windows.Controls;
using TestApp.Helper;
using citPOINT.eNeg.Apps.Common.Interfaces;
using System;

namespace TestApp
{
    [Export]
    public partial class MainPage : UserControl, IObserverApp
    {
        public string AppName
        {
            get
            {
                return TestAppConfiguration.AppName;
            }
        }

        public MainPage()
        {
            InitializeComponent();

            try
            {
                this.ApplyChanges(false);

                TestAppConfiguration.MainPlatformInfo.TrackChanges.AddObserverApp(this);
            }
            catch (Exception ex)
            {
                TestAppConfiguration.MainPlatformInfo.HandleException
                    .HandleException(ex, TestAppConfiguration.AppName);
            }
        }

        public void ApplyChanges(bool isActive)
        {
            if (isActive) //this app is active to selected negotiation
            {
                if (TestAppConfiguration.MainPlatformInfo.UserInfo != null)
                {
                    lblUserEmail.Text = TestAppConfiguration.MainPlatformInfo.UserInfo.EmailAddress;
                }

                if (TestAppConfiguration.MainPlatformInfo.CurrentNegotiation != null)
                {
                    lblNegotiationName.Text
                        = TestAppConfiguration.MainPlatformInfo.CurrentNegotiation.NegotiationName;
                }


                if (TestAppConfiguration.MainPlatformInfo.CurrentConversation != null)
                {
                    lblConversationName.Text
                        = TestAppConfiguration.MainPlatformInfo.CurrentConversation.ConversationName;
                }

                #region Application Info

                IeNegApplication appInfo
                    = TestAppConfiguration.MainPlatformInfo.GetApplicationInfo(this.AppName);


                lblApplicationInfo.Text
                    = string.Format(@"
AppID           ={0}
Title           ={1}
Main Service URl={2}
eNeg URL        ={3}",
appInfo.ApplicationID,
appInfo.ApplicationTitle,
appInfo.ApplicationMainServicePath,
"http://" +
App.Current.Host.Source.Host.ToString() + ":" +
App.Current.Host.Source.Port.ToString() + "/");
                
                #endregion
            }
        }

    }
}

